score module
============

.. automodule:: score
   :members:
   :undoc-members:
   :show-inheritance:
