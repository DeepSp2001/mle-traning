.. housing_price_predictor documentation master file, created by
   sphinx-quickstart on Sun Jun 23 23:09:40 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to housing_price_predictor's documentation!
===================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   basic
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
