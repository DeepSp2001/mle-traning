scripts
=======

.. toctree::
   :maxdepth: 4

   ingest_data
   score
   train
